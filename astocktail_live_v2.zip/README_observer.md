# AStockTail V2：14:45初筛、尾盘技术复核、次交易日10点追踪

完整独立程序，Python 3.11+，Ubuntu / 腾讯云；不依赖原strategy.py、AKShare、pandas。
主观察组：C + MA5 > MA10。只生成观察结果和通知，不自动下单。
保留原C、B+MA5>MA10作对照，参数不再根据少数历史样本调整。

## 先安装、检查，再开始明天验证

把本压缩包上传到腾讯云 `~/astocktail-cloud/`，执行：

```bash
cd ~/astocktail-cloud
unzip -o astocktail_live_v2.zip
# 沿用已有虚拟环境；若不存在，先执行 python3 -m venv .venv
.venv/bin/python -m pip install -r requirements_observer.txt
.venv/bin/python -m unittest test_observer test_live_v2 -v
.venv/bin/python -u astocktail_observer.py doctor
```

仅在doctor返回passed后安装定时器：

```bash
sudo bash install_observer.sh "$PWD" ubuntu
nano observer.env
```

将现有Server酱SendKey写入 `observer.env`：

```text
SERVERCHAN_SENDKEY=你的SendKey
```

保存退出。程序每次启动都会重新读取该文件，不需重启定时器。不要将密钥提交GitHub。
安装器会保留现有observer.env；支持第三个参数指定其他通知环境文件。
`doctor`不发通知，接口包括榜单、基础字段、股本、日K、个股和指数分钟K。
它不代表盘中速度、整市场覆盖率或手机送达都已验证。
本版本已在离线模拟数据上验证，未在你的腾讯云行情网络上实测。
若doctor失败，把doctor.json或终端输出发来；不要将失败当作“今天没有候选”。

## 时间表（北京时间，韩国时间加1小时）

| 时间 | 行为 |
| --- | --- |
| 14:44:55 | systemd启动，先检查当日指数交易会话 |
| 14:45 | 唯一一次涨幅榜扫描，分页初筛，随后准备股本和历史日K |
| 14:50起 | 分析截至14:49的完整个股/指数分钟数据 |
| 14:54:30 | 停止发起行情复核，未完成的标记缺失/超时 |
| 14:55前 | 写入结果并尝试Server酱通知，最多推送3只 |
| 次交易日09:59:55 | 启动追踪，10:00后采样 |
| 10:00:05至10:02 | 记录实时快照，用明确当日10:00分钟收盘价判断前日结果 |
| 15:20 | 补充原有1/3/5交易日收盘收益统计，不更改冻结信号 |
| 16:30 | 清理，保留最近10个市场交易日；原始行情另限512MiB |

“明天”按本次请求的韩国日期2026-11-04理解为2026-11-05。
若要验证11月4日，安装完成后同样会在下一个14:45自动运行，无需改日期。
所有任务每天重复，休市时依据当日指数日K没有交易会话而跳过。
不用把服务器系统时区改为中国时区；systemd表达式已经带Asia/Shanghai。
服务器必须开机、联网且时间准确。关腾讯云网页不影响systemd任务。

## 冻结规则

### 基础筛选

14:45涨幅榜先保留涨幅3%–5%的沪深A股；准备数据后严格要求：
- 涨幅3%–5%，边界包含。
- 量比 > 1。
- 换手率5%–10%，边界包含。
- 流通市值50亿–200亿元，边界包含。

量比口径沿用当前观察程序：累计成交量/已经过交易分钟数，除以前5个完整交易日平均日成交量/240。
它是自算量比，可能不同于行情软件的展示值。成交量单位手、股本单位股、金额单位元。
初筛使用14:45榜单的价量和当次披露股本；最终再次用14:49完整分钟数据核验基础条件。
14:45未进入初筛池的股票不会在14:49补进；这是本轮固定候选池验证的范围。

### 技术条件（沿用当前V3/V4口径）

- 从10:00到14:49的200个交易分钟，分5组、每组40分钟，组5成交量中位数 > (组3中位数+组4中位数)/2。
- 个股与对应指数逐分钟对齐，09:31至14:49收益强于指数。
- 当天至少70%分钟收盘价在累计VWAP之上。VWAP=累计成交额/(累计成交量×100)。
- C形态：14:40–14:49至少一个分钟高点达到此前13:01以来最高点的99.5%。比较基准不含当前分钟。
- 其后另一个完整分钟出现至少0.05%回踩；触发后到回踩分钟的全部低点均不破对应VWAP。
- MA5 > MA10：此前完整日收盘价 + 当天14:49参考价计算，不用今天15:00收盘价。
- B对照组要求真正突破此前14:00以来高点，其他条件相同。

当前股本是披露口径，不保证与交易所当时真实流通股本完全一致。
强制完整229个个股分钟，指数完整对齐；字段缺失、错误、数据过旧均不能认定通过。
最多准备300只、技术复核100只、主组推送3只；顺序按量比降序、换手率降序、代码升序。
榜单最多20页×80条、最多20秒扫描；分页实时变化可能重复、乱序或遗漏。
容量、超时、接口失败均记录在报告；部分成功会标partial，不能解释成全市场严格只有这几只。
到达截止时间后不会补发迟到的候选；可以输出超时/故障状态。
网络、主机和通知服务不受程序控制，因此14:55是程序截止目标，不能保证手机在14:55前收到。

## 次日胜负定义

参考入场价固定为前日14:49分钟收盘价；不是实际成交价。
前日必须是指数交易日历中的上一市场交易日，周五信号在下一交易日追踪，节假日顺延。
10点任务只允许09:59–10:02前启动；晚间手动运行不会用晚间行情回填。
获取实时快照供审计，同时要求返回当日明确10:00分钟线，等待完整分钟结束后取其收盘价。
不使用10:01价格、前日价格、停牌时零成交分钟或其他时刻价格替代；失败记missing，不判输。

收益 = (次交易日10:00价 / 信号日14:49参考价 - 1) × 100%。
- 正数：win（胜）。
- 负数：loss（负）。
- 相等：flat（平）。

主统计只计推送的最多3只；所有对照组信号也记录，CSV用planned_push区分。
胜率=胜/(胜+负+平)，missing不进分母。原始未复权价格，未扣手续费和滑点；除权除息可能影响价格比较。
次日10点结果一经保存不覆盖；同一日选股也不重算、不重复推送。
如果10点任务完全未运行，该日不补造实时观测。

## 结果在哪里

```bash
cat observer_data/latest.json
cat observer_data/morning_summary.csv
cat observer_data/morning_stats.json
cat observer_data/cleanup_latest.json
journalctl -u astocktail-observer-run.service -n 100 --no-pager
journalctl -u astocktail-observer-track.service -n 100 --no-pager
systemctl list-timers --all 'astocktail-observer-*' --no-pager
```

- `observer_data/live/YYYY-MM-DD/signals.json`：冻结的全部技术结果、主组推送名单、错误、规则和时间证据。
- `observer_data/live/YYYY-MM-DD/raw/`：请求原始响应、耗时。
- `observer_data/track/YYYY-MM-DD/results.json`：当日10点对前一交易日信号的判断。
- `observer_data/morning_summary.csv`：滚动10交易日逐只追踪结果。
- `observer_data/outcomes/summary.csv`：原有1/3/5交易日收盘表现及周度汇总。
- 通知记录中的accepted_by_service仅表示服务已受理，无法证明手机已经送达。

## 清理范围和升级

只清理这套程序生成的`observer_data/`，不扫描/删除原项目的data、replay_reports、原回测缓存、代码、虚拟环境和密钥。
它可接续原V1的observer_data信号记录；原V1已有同名systemd定时器会更新为本次时间。
清理包括旧逐日信号、追踪、原始请求、演练、诊断、收益快照，以及汇总中对应旧记录。
交易日历不足或过旧时跳过清理，避免按错误日历误删；16:30查看日志可发现这类失败。
最近10个交易日内的原始响应在合计超过512MiB时可能提前删除，冻结信号与追踪结果仍保留。
清理不控制系统日志、其他程序和旧项目目录的磁盘占用，无法保证整台服务器绝不满盘。
清理与选股/追踪/收盘更新使用互斥锁，写入中跳过；删除范围不跟随符号链接。

独立运行所有新测试：

```bash
.venv/bin/python -m unittest test_observer test_live_v2 -v
```

原GitHub Actions、原cron或其他命名的服务不会被安装器自动禁用；若还发旧通知，请停掉对应旧任务。
原Streamlit app.py未改动；新结果通过文件、终端和Server酱查看，旧网页不会自动显示新目录。
这次未包含历史80笔缓存重导入；保留已有回测缓存，可用于之后比对，避免与新实时样本混合。

手动检查/演练不下单且不推送：

```bash
.venv/bin/python -u astocktail_observer.py doctor
# 非交易时段/15:10后，按最近交易日演练，数据存入rehearsal，不混进实时记录
.venv/bin/python -u astocktail_observer.py rehearse
```

停止本版本定时器：

```bash
sudo systemctl disable --now astocktail-observer-{run,track,update,cleanup}.timer
```
