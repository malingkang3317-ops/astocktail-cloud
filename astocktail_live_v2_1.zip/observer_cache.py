"""Daily reusable preparation cache. No strategy rules or notification secrets."""
from __future__ import annotations
from collections import Counter
from datetime import datetime
import fcntl
import json
import os
from pathlib import Path
import shutil
import time


def managed_write(path, content, immutable, budget, reserve):
    """Serialize writes and reserve bytes before committing; recheck usage every 60s.

    Reservations are conservative across crashes: allocate positive deltas first,
    release shrinking-file bytes only after successful replacement. Old raw/cache
    files may be evicted, but frozen signals are never budget eviction targets.
    """
    path = Path(path).absolute()
    base = next(p for p in path.parents if p.name == 'observer_data')
    if base.is_symlink() or any(p.is_symlink() for p in [path, *path.parents] if p == base or base in p.parents):
        raise ValueError('managed_write_symlink')
    state_path = base / '.storage_budget.json'
    def scan():
        all_files = []
        for directory, dirs, names in os.walk(base, followlinks=False):
            dirs[:] = [d for d in dirs if not (Path(directory) / d).is_symlink()]
            for name in names:
                p = Path(directory) / name
                if p in (state_path, base / '.storage_budget.lock') or p.is_symlink(): continue
                if p.is_file(): all_files.append(p)
        return all_files
    def save(state):
        temp = state_path.with_suffix('.tmp')
        temp.write_text(json.dumps(state), encoding='utf-8'); temp.replace(state_path)
    with (base / '.storage_budget.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if immutable and path.exists(): raise FileExistsError(path)
        try:
            state = json.loads(state_path.read_text())
            if (not isinstance(state['used'], int) or state['used'] < 0 or
                not 0 <= time.time() - state['checked_at'] <= 60):
                raise ValueError('rescan')
        except (ValueError, KeyError, TypeError, OSError):
            state = {'used': sum(p.stat().st_size for p in scan()), 'checked_at': time.time()}
        data = content.encode('utf-8')
        old_size = path.stat().st_size if path.exists() else 0
        delta = len(data) - old_size
        extra = max(0, delta)
        if state['used'] + extra > budget:
            files = scan()
            # Recompute under the same lock so evictions and all writers agree.
            state['used'] = sum(p.stat().st_size for p in files)
            candidates = [p for p in files if p != path and
                          ('raw' in p.relative_to(base).parts or
                           p.parent == base / 'cache' / 'stocks')]
            for p in sorted(candidates, key=lambda x: (0 if 'raw' in x.relative_to(base).parts else 1, x.stat().st_mtime)):
                if state['used'] + extra <= budget: break
                size = p.stat().st_size; p.unlink(); state['used'] -= size
            if state['used'] + extra > budget:
                save(state)
                raise OSError('managed_storage_budget_exceeded_protected_records')
        if shutil.disk_usage(base).free < reserve + len(data):
            raise OSError('insufficient_free_space_reserve_512MiB')
        state['used'] += extra
        save(state)
        temp_path = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
        if immutable:
            with path.open('xb') as f: f.write(data)
        else:
            temp_path.write_bytes(data); temp_path.replace(path)
        if delta < 0:
            state['used'] += delta; save(state)


def safe_reason(exc):
    # Only our own validation text is exposed; network exceptions may contain URLs.
    return str(exc)[:160] if isinstance(exc, ValueError) else type(exc).__name__


class PreparationCache:
    def __init__(self, root, api, calendar, day):
        self.base = Path(root) / 'observer_data' / 'cache'
        self.api, self.day, self.calendar = api, day, calendar
        self.previous = sorted(d for d in calendar if d < day)[-5:]
        self.session = self.previous[-1] if self.previous else None
        self.events = []

    def _path(self, code):
        if self.api.code_of({'full_code': code}) != code:
            raise ValueError('invalid_cache_code')
        return self.base / 'stocks' / (code + '.json')

    def load(self, code):
        path = self._path(code)
        if not path.exists():
            return None, None
        try:
            if path.is_symlink() or self.base.is_symlink() or path.parent.is_symlink():
                raise ValueError('cache_symlink')
            entry = json.loads(path.read_text(encoding='utf-8'))
            if entry.get('schema') != 1 or entry.get('code') != code:
                raise ValueError('cache_identity_mismatch')
            p = entry.get('profile')
            if (entry.get('profile_day') != self.day or not p or
                self.api.code_of(p['data']) != code or
                self.api.number(p['data']['circulating_shares']) <= 0):
                p = None
            history = entry.get('daily')
            if (entry.get('daily_checked_session') != self.session or not history or
                len(self.previous) != 5):
                history = None
            if history:
                # Validate serialized OHLC and numeric values again, not only freshness labels.
                history = self.api.daily_map([{'time': d + 'T15:00:00+08:00', **b}
                                              for d, b in history.items() if d < self.day])
                if any(d not in history or history[d]['volume_lots'] <= 0 for d in self.previous):
                    history = None
            return p, history
        except (ValueError, KeyError, TypeError, OSError) as exc:
            self.events.append({'code': code, 'stage': 'cache_read',
                                'error': type(exc).__name__, 'reason': safe_reason(exc)})
            return None, None

    def save(self, code, profile, daily):
        path = self._path(code)
        if self.base.is_symlink() or path.parent.is_symlink() or path.is_symlink():
            raise ValueError('cache_symlink')
        history = {d: b for d, b in (daily or {}).items() if d < self.day}
        # Each version contains at most the recent 40 daily bars, not all historic observations.
        history = dict(sorted(history.items())[-40:])
        entry = {'schema': 1, 'code': code, 'profile': profile,
                 'profile_day': self.day if profile else None,
                 'daily': history,
                 'daily_checked_session': self.session if history else None,
                 'last_used_session': self.day, 'saved_at': self.api.stamp()}
        self.api.write_json(path, entry)


def fetch_inputs(api, market, codes, profiles, histories, day, calendar, deadline, cache=None):
    """Retry missing profiles after trying other batches; deadline is always authoritative."""
    codes = list(dict.fromkeys(codes))
    stats = {'cache_profile_hits': 0, 'cache_daily_hits': 0, 'profile_retries': 0,
             'daily_retries': 0, 'errors': [], 'profile_circuit_open': False}
    errors = stats['errors']
    if cache:
        for code in codes:
            p, h = cache.load(code)
            if p and code not in profiles:
                profiles[code] = p; stats['cache_profile_hits'] += 1
            if h and code not in histories:
                histories[code] = h; stats['cache_daily_hits'] += 1
        errors.extend(cache.events)
    pending = [c for c in codes if c not in profiles]
    profile_stop = time.monotonic() + max(0, deadline - time.monotonic()) * .65
    consecutive = 0
    for attempt in range(2):
        if not pending or time.monotonic() >= profile_stop:
            break
        batch_size = api.RULES['profile_batch_size'] if attempt == 0 else 1
        todo = pending; pending = []
        for start in range(0, len(todo), batch_size):
            batch = todo[start:start + batch_size]
            if time.monotonic() >= profile_stop or consecutive >= 3:
                pending.extend(todo[start:]); break
            if attempt:
                stats['profile_retries'] += len(batch)
            try:
                rows = api.rows_of(market.call('profile', profile_stop, codes=batch), ('rows',))
                received = 0
                for row in rows:
                    code = api.code_of(row)
                    if code in batch and api.number(row.get('circulating_shares', 0)) > 0:
                        profiles[code] = {'data': row, 'collected_at': api.stamp()}
                        received += 1
                if not received:
                    raise ValueError('empty_profile_batch')
                consecutive = 0
                absent = [c for c in batch if c not in profiles]
                pending.extend(absent)
                for code in absent:
                    errors.append({'code': code, 'stage': 'profile', 'attempt': attempt + 1,
                                   'error': 'MissingProfile', 'reason': 'code_not_returned_or_invalid_shares'})
            except Exception as exc:
                consecutive += 1; pending.extend(batch)
                errors.append({'codes': batch, 'stage': 'profile', 'attempt': attempt + 1,
                               'error': type(exc).__name__, 'reason': safe_reason(exc)})
        if consecutive >= 3:
            stats['profile_circuit_open'] = True; break
    previous = sorted(d for d in calendar if d < day)[-5:]
    pending = [c for c in codes if c in profiles and c not in histories]
    for attempt in range(2):
        if not pending or time.monotonic() >= deadline:
            break
        again = []
        for code in pending:
            if time.monotonic() >= deadline:
                break
            if attempt:
                stats['daily_retries'] += 1
            try:
                raw = market.call('bars', deadline, code=code, period='day', count=40)
                history = api.daily_map(api.rows_of(raw, ('bars',)))
                history = {d: b for d, b in history.items() if d < day}
                if len(previous) != 5 or any(d not in history or history[d]['volume_lots'] <= 0 for d in previous):
                    raise ValueError('missing_prior_five_market_sessions')
                histories[code] = history
            except Exception as exc:
                again.append(code)
                errors.append({'code': code, 'stage': 'daily', 'attempt': attempt + 1,
                               'error': type(exc).__name__, 'reason': safe_reason(exc)})
        pending = again
    if cache:
        for code in codes:
            if code in profiles or code in histories:
                try:
                    cache.save(code, profiles.get(code), histories.get(code))
                except (ValueError, OSError) as exc:
                    errors.append({'code': code, 'stage': 'cache_write',
                                   'error': type(exc).__name__, 'reason': safe_reason(exc)})
    stats.update(profile_available=sum(c in profiles for c in codes),
                 daily_available=sum(c in histories for c in codes))
    return stats


def prepare_candidates(api, market, hits, pool, profiles, histories, day, deadline, cache=None, calendar=None):
    hits = sorted(hits, key=lambda r: (r['rank'], r['code']))
    if calendar is None:
        # Direct callers may already have daily history; production always passes market calendar.
        calendar = sorted({d for h in histories.values() for d in h if d < day})
        if len(calendar) < 5:
            calendar = api.market_calendar(market, deadline)
    fetched = fetch_inputs(api, market, [r['code'] for r in hits], profiles, histories,
                           day, calendar, deadline, cache)
    stats = {'rank_band': len(hits), 'prepared': 0, 'basic_rejected': 0,
             'missing': 0, 'capacity_skipped': 0, **fetched, 'missing_reasons': {}}
    reasons = Counter()
    for item in hits:
        code = item['code']
        try:
            if code not in profiles: raise ValueError('missing_profile_after_retry_or_deadline')
            if code not in histories: raise ValueError('missing_daily_after_retry_or_deadline')
            metrics = api.pre_metrics(item, profiles[code]['data'], histories[code], day)
            stats['prepared'] += 1
            if metrics['eligible']:
                pool[code] = {**item, 'pre': metrics, 'name': profiles[code]['data'].get('name', code)}
            else:
                pool.pop(code, None); stats['basic_rejected'] += 1
        except Exception as exc:
            stats['missing'] += 1; reason = safe_reason(exc); reasons[reason] += 1
            stats['errors'].append({'code': code, 'stage': 'prepare',
                                    'error': type(exc).__name__, 'reason': reason})
    stats.update(pool_size=len(pool), missing_reasons=dict(reasons))
    return stats


def prewarm(api, root):
    base = Path(root) / 'observer_data'; base.mkdir(parents=True, exist_ok=True)
    lock = (base / 'prewarm.lock').open('a')
    market = None
    report = {'started_at': api.stamp(), 'status': 'starting', 'errors': []}
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        current = api.now(); day = current.date().isoformat()
        if current.weekday() >= 5 or current >= api.at(day, '14:43'):
            report['status'] = 'outside_prewarm_window'; return 0
        stop = min(time.monotonic() + api.RULES['prewarm_seconds'],
                   time.monotonic() + (api.at(day, '14:43') - current).total_seconds())
        market = api.Market()  # No multi-thousand-stock raw copies; normalized cache is sufficient.
        calendar = api.market_calendar(market, min(stop, time.monotonic() + 20))
        if day not in calendar:
            report['status'] = 'no_current_session_data'; return 2
        cache = PreparationCache(root, api, calendar, day)
        codes = []; seen = set(); signatures = set()
        scan_stop = min(stop, time.monotonic() + api.RULES['universe_seconds'])
        report['universe_complete'] = False
        for page in range(1000):
            if time.monotonic() >= scan_stop:
                report['universe_stop'] = 'time_limit'; break
            try:
                rows = api.rows_of(market.call('rank', scan_stop, category='沪深A股',
                                   sort_by='代码', start=page * 80, count=80, ascending=True), ('records',))
                sig = tuple((str(r.get('exchange')), str(r.get('code'))) for r in rows)
                if rows and sig in signatures:
                    report['universe_stop'] = 'repeated_page'; break
                signatures.add(sig)
                for row in rows:
                    code = api.code_of(row)
                    if code and code not in seen:
                        seen.add(code); codes.append(code)
                if len(rows) < 80:
                    report.update(universe_complete=True, universe_stop='end_of_list'); break
            except Exception as exc:
                report['universe_stop'] = type(exc).__name__
                report['errors'].append({'stage': 'universe', 'reason': safe_reason(exc)})
                break
        # Reuse prior discovery if the current discovery was interrupted; all rows still revalidated.
        upath = cache.base / 'universe.json'
        if upath.exists() and not upath.is_symlink():
            try:
                old = json.loads(upath.read_text())
                if (datetime.fromisoformat(day).date() - datetime.fromisoformat(old['day']).date()).days <= 7:
                    for code in old.get('codes', []):
                        if api.code_of({'full_code': code}) == code and code not in seen:
                            seen.add(code); codes.append(code)
            except (ValueError, KeyError, TypeError, OSError):
                pass
        if not codes: raise ValueError('empty_prewarm_universe')
        api.write_json(upath, {'day': day, 'codes': codes, 'complete': report['universe_complete']})
        # Resume missing entries first; otherwise one slow endpoint repeatedly starves the tail.
        profiles = {}; histories = {}; incomplete = []; complete = []
        for code in codes:
            p, h = cache.load(code)
            (complete if p and h else incomplete).append(code)
        progress = []
        ordered = incomplete + complete
        for start in range(0, len(ordered), 80):
            if time.monotonic() >= stop: break
            chunk = ordered[start:start + 80]
            progress.append(fetch_inputs(api, market, chunk, profiles, histories, day, calendar,
                                         min(stop, time.monotonic() + 120), cache))
        report.update(universe=len(codes), prepared=sum(c in profiles and c in histories for c in codes),
                      missing=[c for c in codes if c not in profiles or c not in histories], batches=progress)
        report['status'] = 'ok' if not report['missing'] and report['universe_complete'] else 'partial'
        return 0 if report['status'] == 'ok' else 2
    except BlockingIOError:
        report['status'] = 'already_running'; return 2
    except Exception as exc:
        report.update(status='failed', error=type(exc).__name__, reason=safe_reason(exc)); return 2
    finally:
        if market: market.close()
        report['finished_at'] = api.stamp()
        if report['status'] != 'already_running':
            directory = base / 'prewarm' / api.now().date().isoformat()
            api.write_json(directory / (api.now().strftime('%H%M%S_%f') + '.json'), report)
            api.write_json(base / 'prewarm_latest.json', report)
        lock.close()
        api.log('资料预热：' + report['status'] + '；已准备' + str(report.get('prepared', 0)) + '只')


def storage_housekeeping(api, root, boundary):
    """20GB decimal total managed-data budget; frozen records kept for 10 sessions."""
    base = Path(root) / 'observer_data'
    if base.is_symlink(): raise ValueError('managed_root_symlink')
    def files(parent):
        result = []
        if not parent.exists() or parent.is_symlink(): return result
        for directory, dirs, names in os.walk(parent, followlinks=False):
            dirs[:] = [d for d in dirs if not (Path(directory) / d).is_symlink()]
            for name in names:
                p = Path(directory) / name
                if p.is_file() and not p.is_symlink(): result.append(p)
        return result
    removed = []
    stocks = base / 'cache' / 'stocks'
    for p in files(stocks):
        if p.suffix != '.json': continue
        try:
            entry = json.loads(p.read_text())
            if entry.get('last_used_session', '') < boundary:
                p.unlink(); removed.append(str(p.relative_to(base)))
        except (ValueError, OSError):
            # Corrupt cache is replaceable. Never apply this rule to frozen signals.
            p.unlink(missing_ok=True); removed.append(str(p.relative_to(base)))
    all_files = files(base)
    total = sum(p.stat().st_size for p in all_files)
    budget = api.RULES['storage_budget_bytes']
    expendable = [p for p in all_files if 'raw' in p.relative_to(base).parts]
    expendable += [p for p in files(stocks) if p not in expendable]
    for p in sorted(expendable, key=lambda x: (0 if 'raw' in x.relative_to(base).parts else 1, x.stat().st_mtime)):
        if total <= budget: break
        size = p.stat().st_size; p.unlink(); total -= size
        removed.append(str(p.relative_to(base)))
    return {'budget_bytes': budget, 'managed_bytes_remaining': total, 'removed': removed,
            'budget_met': total <= budget,
            'scope': 'observer_data_only', 'protected_frozen_records': True}
