#!/usr/bin/env bash
# Stage and test before touching deployed source. No credentials or signals copied.
set -euo pipefail
repo_dir=$(realpath "${1:-.}")
archive=$(realpath "${2:-$repo_dir/astocktail_live_v2_1.zip}")
python_bin="$repo_dir/.venv/bin/python"
[[ -x "$python_bin" ]] || { echo '未找到项目虚拟环境'; exit 1; }
stage_dir=$(mktemp -d)
trap 'rm -rf "$stage_dir"' EXIT
"$python_bin" - "$archive" "$stage_dir" <<'PY'
from pathlib import Path
import sys, zipfile
archive, dest = sys.argv[1:]
with zipfile.ZipFile(archive) as z:
    for name in z.namelist():
        p = Path(name)
        if p.is_absolute() or '..' in p.parts or len(p.parts) != 1:
            raise SystemExit('不接受包含路径的升级包')
    z.extractall(dest)
PY
for name in astocktail_observer.py observer_cache.py install_observer.sh requirements_observer.txt README_observer.md test_observer.py test_live_v2.py test_lunch_boundary.py test_cache_optimization.py; do
    [[ -f "$stage_dir/$name" ]] || { echo "升级包缺少$name"; exit 1; }
done
original_hash=$(sha256sum "$repo_dir/astocktail_observer.py" | cut -d ' ' -f1)
(cd "$stage_dir" && "$python_bin" -m unittest discover -v && bash -n install_observer.sh)
current_hash=$(sha256sum "$repo_dir/astocktail_observer.py" | cut -d ' ' -f1)
[[ "$original_hash" == "$current_hash" ]] || { echo '测试期间原脚本变化，停止升级'; exit 1; }
backup="$repo_dir/observer_backups/$(date +%Y%m%d_%H%M%S)_$$"
mkdir -p "$backup"
for name in astocktail_observer.py observer_cache.py install_observer.sh requirements_observer.txt README_observer.md test_observer.py test_live_v2.py test_lunch_boundary.py test_cache_optimization.py; do
    if [[ -e "$repo_dir/$name" ]]; then cp -p "$repo_dir/$name" "$backup/$name"; fi
done
for name in astocktail_observer.py observer_cache.py install_observer.sh requirements_observer.txt README_observer.md test_observer.py test_live_v2.py test_lunch_boundary.py test_cache_optimization.py; do
    cp "$stage_dir/$name" "$repo_dir/$name.new"
    mv "$repo_dir/$name.new" "$repo_dir/$name"
done
if [[ -d "$repo_dir/.git" ]]; then
    touch "$repo_dir/.git/info/exclude"
    if ! grep -Fxq '/observer_backups/' "$repo_dir/.git/info/exclude"; then
        echo '/observer_backups/' >> "$repo_dir/.git/info/exclude"
    fi
fi
echo "V2.1.0源文件已更新；原程序备份：$backup"
echo '请先运行doctor，通过后重新运行install_observer.sh安装5个定时器。'
echo '未修改密钥、信号或定时器，未发送通知。'
