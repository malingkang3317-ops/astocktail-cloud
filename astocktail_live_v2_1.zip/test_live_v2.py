import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from datetime import datetime,timedelta
from unittest.mock import patch
import astocktail_observer as o
from test_observer import fixture, FakeMarket, DAY

class MorningTests(unittest.TestCase):
    def bar(self,day='2026-11-04',hm='10:00',price=10.1):
        return {'time':f'{day}T{hm}:00+08:00','close':price,'high':price+.1,'low':price-.1,'volume_lots':100}
    def test_exact_minute_and_flat(self):
        signal={'signal_price_1449':10}
        current=o.at('2026-11-04','10:01')
        for price,verdict in [(10.1,'win'),(9.9,'loss'),(10,'flat')]:
            r=o.morning_value(signal,[self.bar(price=price),self.bar(hm='10:01',price=999)],'2026-11-04',current)
            self.assertEqual(r['verdict'],verdict)
            self.assertEqual(r['price_1000'],price)
    def test_missing_stale_duplicate_and_no_trade_rejected(self):
        signal={'signal_price_1449':10};current=o.at('2026-11-04','10:01')
        samples=[[self.bar(hm='09:59')],[self.bar(day=DAY)],[self.bar(),self.bar()],
                 [{**self.bar(),'volume_lots':0}]]
        for bars in samples:
            with self.assertRaises(ValueError):o.morning_value(signal,bars,'2026-11-04',current)
    def test_1000_not_used_before_complete(self):
        with self.assertRaises(ValueError):
            o.morning_value({'signal_price_1449':10},[self.bar()],'2026-11-04',o.at('2026-11-04','10:00'))
    def test_next_session_full_flow_freezes_results(self):
        current=[o.at('2026-11-04','09:59')]
        row=o.evaluate_candidate(*fixture()[:5],DAY,fixture()[5])
        class MorningMarket(FakeMarket):
            def call(inner,op,deadline,**kw):
                if op=='snapshot':return [{'full_code':'sz002531','last_price':10.2}]
                if kw.get('period')=='day':
                    cal=fixture()[5];cal={**cal,'2026-11-04':cal[DAY]}
                    return {'bars':[{'time':d+'T15:00:00+08:00',**v} for d,v in cal.items()]}
                return {'bars':[MorningTests().bar()]}
        with tempfile.TemporaryDirectory() as d,patch.object(o,'Market',MorningMarket),patch.object(o,'now',side_effect=lambda:current[0]),patch.object(o,'wait_until',side_effect=lambda t:current.__setitem__(0,t)),contextlib.redirect_stdout(io.StringIO()):
            root=Path(d);p=root/'observer_data/live'/DAY/'signals.json'
            o.write_json(p,{'date':DAY,'rows':[row],'pushed':[row]})
            self.assertEqual(o.track_morning(root),0)
            out=root/'observer_data/track/2026-11-04/results.json';original=out.read_bytes()
            r=json.loads(original);self.assertEqual(r['rows'][0]['verdict'],'win')
            self.assertTrue((root/'observer_data/morning_summary.csv').exists())
            self.assertEqual(o.track_morning(root),0);self.assertEqual(original,out.read_bytes())
    def test_no_late_backfill(self):
        with tempfile.TemporaryDirectory() as d,patch.object(o,'now',return_value=o.at('2026-11-04','10:03')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(o.track_morning(Path(d)),2)
            self.assertFalse((Path(d)/'observer_data/track/2026-11-04/results.json').exists())

class RetentionTests(unittest.TestCase):
    def test_ten_sessions_not_ten_calendar_days_and_external_untouched(self):
        days=['2026-10-19','2026-10-20','2026-10-21','2026-10-22','2026-10-23',
              '2026-10-26','2026-10-27','2026-10-28','2026-10-29','2026-10-30','2026-11-02','2026-11-03']
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);base=root/'observer_data'
            for day in days:o.write_json(base/'live'/day/'signals.json',{'date':day,'rows':[]})
            o.write_json(root/'replay_reports/old.json',{'untouched':True})
            oldkey=days[0]+'|sz000001';newkey=days[-1]+'|sz000001'
            o.write_json(base/'outcomes/latest.json',{'records':{oldkey:{},newkey:{}}})
            r=o.prune_data(root,dict.fromkeys(days),o.at('2026-11-03','16:30'))
            self.assertEqual(r['oldest_retained_session'],days[2])
            self.assertEqual(len(list((base/'live').iterdir())),10)
            self.assertTrue((root/'replay_reports/old.json').exists())
            self.assertNotIn(oldkey,json.loads((base/'outcomes/latest.json').read_text())['records'])
    def test_stale_calendar_does_not_delete(self):
        days={f'2026-10-{n:02d}':{} for n in range(1,21)}
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):o.prune_data(Path(d),days,o.at('2026-11-03','16:30'))
    def test_symlink_target_not_deleted(self):
        days={f'2026-10-{n:02d}':{} for n in range(1,21)}
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);other=root/'other';other.mkdir();(other/'keep').write_text('yes')
            (root/'observer_data/live').mkdir(parents=True)
            (root/'observer_data/live/2026-01-01').symlink_to(other,target_is_directory=True)
            o.prune_data(root,days,o.at('2026-10-20','16:30'))
            self.assertTrue((other/'keep').exists())

if __name__=='__main__':unittest.main()
