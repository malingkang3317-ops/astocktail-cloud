import contextlib
import copy
from datetime import datetime
import io
import json
from pathlib import Path
import tempfile
import time
import unittest
from unittest.mock import patch

import astocktail_observer as o
from observer_cache import PreparationCache, fetch_inputs, managed_write, prewarm, storage_housekeeping
from test_observer import DAY, FakeMarket, fixture


class CacheTests(unittest.TestCase):
    def cache(self, root):
        return PreparationCache(root, o, fixture()[5], DAY)

    def test_fresh_cache_avoids_all_network(self):
        item, daily, profile, *_ = fixture()
        class NoNetwork:
            def call(self, *a, **kw): raise AssertionError('cache must be sufficient')
        with tempfile.TemporaryDirectory() as root:
            cache = self.cache(root); cache.save(item['code'], profile, daily)
            profiles = {}; histories = {}
            stats = fetch_inputs(o, NoNetwork(), [item['code']], profiles, histories,
                                 DAY, fixture()[5], time.monotonic() + 5, cache)
            self.assertEqual(stats['cache_profile_hits'], 1)
            self.assertEqual(stats['cache_daily_hits'], 1)
            self.assertEqual(histories[item['code']], daily)

    def test_next_day_never_reuses_old_profile_or_old_daily_check(self):
        item, daily, profile, *_ = fixture()
        with tempfile.TemporaryDirectory() as root:
            self.cache(root).save(item['code'], profile, daily)
            later = PreparationCache(root, o, fixture()[5], '2026-11-04')
            self.assertEqual(later.load(item['code']), (None, None))

    def test_current_day_daily_close_not_saved(self):
        item, daily, profile, *_ = fixture()
        daily = {**daily, DAY: fixture()[5][DAY]}
        with tempfile.TemporaryDirectory() as root:
            cache = self.cache(root); cache.save(item['code'], profile, daily)
            _, history = cache.load(item['code'])
            self.assertNotIn(DAY, history)

    def test_corrupt_cache_records_reason_and_falls_back(self):
        with tempfile.TemporaryDirectory() as root:
            cache = self.cache(root); p = cache._path('sz002531')
            p.parent.mkdir(parents=True); p.write_text('broken')
            self.assertEqual(cache.load('sz002531'), (None, None))
            self.assertEqual(cache.events[0]['stage'], 'cache_read')

    def test_missing_recent_session_cache_is_rejected(self):
        item, daily, profile, *_ = fixture()
        daily = dict(daily); daily.pop(max(daily))
        with tempfile.TemporaryDirectory() as root:
            cache = self.cache(root); cache.save(item['code'], profile, daily)
            p, h = cache.load(item['code'])
            self.assertIsNotNone(p); self.assertIsNone(h)

    def test_partial_batch_retries_only_missing_code(self):
        item, daily, profile, *_ = fixture()
        class Partial(FakeMarket):
            def __init__(self): self.calls = []
            def call(self, op, deadline, **kw):
                if op != 'profile': return super().call(op, deadline, **kw)
                self.calls.append(kw['codes'])
                codes = kw['codes'][:1] if len(self.calls) == 1 else kw['codes']
                return {'rows': [{**profile['data'], 'full_code': c} for c in codes]}
        market = Partial(); profiles = {}; histories = {}
        stats = fetch_inputs(o, market, ['sz002531', 'sh600000'], profiles, histories,
                             DAY, fixture()[5], time.monotonic() + 5)
        self.assertEqual(market.calls, [['sz002531', 'sh600000'], ['sh600000']])
        self.assertEqual(len(profiles), 2); self.assertEqual(len(histories), 2)
        self.assertEqual(stats['profile_retries'], 1)

    def test_transient_timeout_recovers_and_preserves_error_reason(self):
        class Flaky(FakeMarket):
            def __init__(self): self.failed = False
            def call(self, op, deadline, **kw):
                if op == 'profile' and not self.failed:
                    self.failed = True; raise TimeoutError('private endpoint')
                return super().call(op, deadline, **kw)
        profiles = {}; histories = {}
        stats = fetch_inputs(o, Flaky(), ['sz002531'], profiles, histories, DAY,
                             fixture()[5], time.monotonic() + 5)
        self.assertEqual(len(profiles), 1); self.assertEqual(len(histories), 1)
        self.assertEqual(stats['errors'][0]['reason'], 'TimeoutError')
        self.assertNotIn('private', json.dumps(stats))

    def test_no_300_stock_preparation_limit(self):
        item, daily, profile, *_ = fixture()
        class Many(FakeMarket):
            def call(self, op, deadline, **kw):
                if op == 'profile':
                    return {'rows': [{**profile['data'], 'full_code': c} for c in kw['codes']]}
                return super().call(op, deadline, **kw)
        hits = [{**item, 'code': 'sh' + str(600000 + i), 'rank': i} for i in range(350)]
        stats = o.prepare_pool(Many(), hits, {}, {}, {}, DAY, time.monotonic() + 30,
                               calendar=fixture()[5])
        self.assertEqual(stats['prepared'], 350)
        self.assertEqual(stats['capacity_skipped'], 0)

    def test_expired_deadline_makes_no_network_calls_and_reports_each_code(self):
        class NoNetwork:
            def call(self, *a, **kw): raise AssertionError('expired deadline')
        item = fixture()[0]
        stats = o.prepare_pool(NoNetwork(), [item], {}, {}, {}, DAY,
                               time.monotonic() - 1, calendar=fixture()[5])
        self.assertEqual(stats['missing'], 1)
        self.assertEqual(stats['prepared'], 0)
        self.assertIn('missing_profile_after_retry_or_deadline', stats['missing_reasons'])

    def test_cache_symlink_never_reads_external_file(self):
        with tempfile.TemporaryDirectory() as root:
            cache = self.cache(root); p = cache._path('sz002531')
            p.parent.mkdir(parents=True)
            external = Path(root) / 'external'; external.write_text('unchanged')
            p.symlink_to(external)
            self.assertEqual(cache.load('sz002531'), (None, None))
            with self.assertRaises(ValueError): cache.save('sz002531', None, None)
            self.assertEqual(external.read_text(), 'unchanged')

    def test_prewarm_discovers_codes_without_prices_and_reuses_cache(self):
        class Universe(FakeMarket):
            def call(self, op, deadline, **kw):
                if op == 'rank':
                    return {'records': [{'code': '002531', 'exchange': 'sz', 'last_price': 0}]}
                return super().call(op, deadline, **kw)
        with tempfile.TemporaryDirectory() as root, patch.object(o, 'Market', Universe), \
             patch.object(o, 'now', return_value=datetime(2026, 11, 3, 12, 30, tzinfo=o.TZ)), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(prewarm(o, Path(root)), 0)
            report = json.loads((Path(root) / 'observer_data/prewarm_latest.json').read_text())
            self.assertEqual(report['prepared'], 1)
            self.assertTrue(report['universe_complete'])
            self.assertEqual(prewarm(o, Path(root)), 0)
            report = json.loads((Path(root) / 'observer_data/prewarm_latest.json').read_text())
            self.assertEqual(report['batches'][0]['cache_profile_hits'], 1)

    def test_prewarm_will_not_compete_during_tail_scan(self):
        class NoNetwork:
            def __init__(self): raise AssertionError('no network after 14:43')
        with tempfile.TemporaryDirectory() as root, patch.object(o, 'Market', NoNetwork), \
             patch.object(o, 'now', return_value=datetime(2026, 11, 3, 14, 45, tzinfo=o.TZ)), \
             contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(prewarm(o, Path(root)), 0)

    def test_live_uses_warm_cache_without_changing_original_signal(self):
        class WarmOnly(FakeMarket):
            def call(self, op, deadline, **kw):
                if op == 'profile' or (op == 'bars' and kw['period'] == 'day' and kw.get('kind') != 'index'):
                    raise AssertionError('live stock preparation must come from cache')
                return super().call(op, deadline, **kw)
        item, daily, profile, *_ = fixture()
        clock = [datetime(2026, 11, 3, 14, 44, 55, tzinfo=o.TZ)]
        def advance(target): clock[0] = max(clock[0], target)
        with tempfile.TemporaryDirectory() as root, patch.object(o, 'Market', WarmOnly), \
             patch.object(o, 'now', side_effect=lambda: clock[0]), \
             patch.object(o, 'wait_until', side_effect=advance), contextlib.redirect_stdout(io.StringIO()):
            self.cache(root).save(item['code'], profile, daily)
            self.assertEqual(o.run_observation(Path(root), 'live'), 0)
            report = json.loads((Path(root) / 'observer_data/live' / DAY / 'signals.json').read_text())
            self.assertEqual(report['scans'][0]['prepare']['cache_profile_hits'], 1)
            self.assertEqual(report['analysis']['evaluated'], 1)
            self.assertEqual(len(report['pushed']), 1)
            self.assertEqual(report['pushed'][0]['code'], item['code'])

    def test_all_analysis_failures_are_explicit_not_zero_candidates(self):
        class BrokenIndex(FakeMarket):
            def call(self, op, deadline, **kw):
                data = super().call(op, deadline, **kw)
                if op == 'bars' and kw['period'] == '1m' and kw.get('kind') == 'index':
                    data['bars'].pop(100)
                return data
        with tempfile.TemporaryDirectory() as root, patch.object(o, 'Market', BrokenIndex), \
             patch.object(o, 'now', return_value=datetime(2026, 11, 3, 16, tzinfo=o.TZ)), \
             patch.object(o.time, 'sleep'), contextlib.redirect_stdout(io.StringIO()):
            o.run_observation(Path(root), 'rehearsal')
            report = json.loads(next(Path(root).glob('observer_data/rehearsal/*/signals.json')).read_text())
            self.assertEqual(report['status'], 'rehearsal_analysis_failed')
            self.assertEqual(report['analysis']['evaluated'], 0)
            self.assertTrue(report['error'])

    def test_failed_index_is_requested_once_per_retry_pass(self):
        class BrokenIndex:
            def __init__(self): self.calls = 0
            def call(self, op, deadline, **kw):
                self.calls += 1
                return {'bars': fixture()[4][:-1]}
        m = BrokenIndex()
        pool = {f'sz{200000+i}': {'code': f'sz{200000+i}', 'pre': {}} for i in range(25)}
        with patch.object(o.time, 'sleep'):
            rows, stats = o.final_evaluate(m, pool, {}, {}, DAY, fixture()[5], time.monotonic()+10)
        self.assertEqual(m.calls, 2)
        self.assertEqual(len(stats['data_errors']), 25)
        self.assertEqual(rows, [])


class StorageTests(unittest.TestCase):
    def write(self, root, name, data, budget=1000):
        p = Path(root) / 'observer_data' / name; p.parent.mkdir(parents=True, exist_ok=True)
        managed_write(p, data, False, budget, 0)
        return p

    def test_default_budget_is_20_decimal_gb(self):
        self.assertEqual(o.RULES['storage_budget_bytes'], 20_000_000_000)
        self.assertIsNone(o.RULES['max_prepare'])
        self.assertIsNone(o.RULES['max_technical'])

    def test_raw_evicted_before_protected_signal(self):
        with tempfile.TemporaryDirectory() as root:
            signal = self.write(root, 'live/2026-11-03/signals.json', 'x' * 300)
            raw = self.write(root, 'live/2026-11-03/raw/a.json', 'y' * 600)
            p = self.write(root, 'cache/stocks/sh600000.json', 'z' * 400)
            self.assertFalse(raw.exists()); self.assertTrue(signal.exists()); self.assertTrue(p.exists())

    def test_cannot_exceed_budget_by_overwriting_protected_data(self):
        with tempfile.TemporaryDirectory() as root:
            signal = self.write(root, 'live/2026-11-03/signals.json', 'x' * 800)
            with self.assertRaisesRegex(OSError, 'budget_exceeded'):
                self.write(root, 'live/2026-11-04/signals.json', 'y' * 300)
            self.assertEqual(signal.read_text(), 'x' * 800)

    def test_overwrite_accounts_for_delta_and_shrink(self):
        with tempfile.TemporaryDirectory() as root:
            self.write(root, 'cache/stocks/sh600000.json', 'x' * 800)
            self.write(root, 'cache/stocks/sh600000.json', 'x' * 200)
            self.write(root, 'live/2026-11-03/signals.json', 'x' * 700)
            state = json.loads((Path(root) / 'observer_data/.storage_budget.json').read_text())
            self.assertEqual(state['used'], 900)

    def test_immutable_signal_unchanged(self):
        with tempfile.TemporaryDirectory() as root:
            p = self.write(root, 'live/2026-11-03/signals.json', 'original')
            with self.assertRaises(FileExistsError): managed_write(p, 'replacement', True, 1000, 0)
            self.assertEqual(p.read_text(), 'original')

    def test_symlink_write_and_eviction_do_not_follow_external_target(self):
        with tempfile.TemporaryDirectory() as root:
            base = Path(root) / 'observer_data'; base.mkdir()
            external = Path(root) / 'external'; external.write_text('keep')
            (base / 'raw').symlink_to(Path(root), target_is_directory=True)
            p = base / 'raw/new.json'
            with self.assertRaises(ValueError): managed_write(p, 'bad', False, 1000, 0)
            self.assertEqual(external.read_text(), 'keep')

    def test_cleanup_stale_cache_by_market_boundary(self):
        item, daily, profile, *_ = fixture()
        with tempfile.TemporaryDirectory() as root:
            cache = PreparationCache(root, o, fixture()[5], DAY)
            cache.save(item['code'], profile, daily)
            result = storage_housekeeping(o, root, '2026-11-04')
            self.assertFalse(cache._path(item['code']).exists())
            self.assertEqual(result['budget_bytes'], 20_000_000_000)

    def test_disk_reserve_blocks_write(self):
        with tempfile.TemporaryDirectory() as root:
            p = Path(root) / 'observer_data/x.json'; p.parent.mkdir()
            with patch('observer_cache.shutil.disk_usage') as usage:
                usage.return_value.free = 100
                with self.assertRaisesRegex(OSError, 'free_space'):
                    managed_write(p, 'x', False, 1000, 200)
            self.assertFalse(p.exists())


if __name__ == '__main__': unittest.main()
