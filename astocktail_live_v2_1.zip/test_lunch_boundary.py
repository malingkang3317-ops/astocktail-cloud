import contextlib
import copy
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import astocktail_observer as o
from test_observer import fixture, FakeMarket, DAY

def wire(rows):
    return [{**r, 'time': r['time'].replace('T11:30:', 'T13:00:')} for r in rows]

class LunchTests(unittest.TestCase):
    def test_stock_prices_amounts_volumes_and_signals_preserved(self):
        v = list(fixture())
        expected = o.evaluate_candidate(*v[:5], DAY, v[5])
        v[3], v[4] = wire(v[3]), wire(v[4])
        before = copy.deepcopy(v)
        actual = o.evaluate_candidate(*v[:5], DAY, v[5])
        for key in ('basic', 'common_flags', 'common_metrics', 'variants', 'groups', 'ma5', 'ma10'):
            self.assertEqual(expected[key], actual[key], key)
        self.assertEqual(v, before)
        self.assertEqual(len(actual['minute_time_adjustments']['stock']), 1)
        self.assertEqual(len(actual['minute_time_adjustments']['index']), 1)
        points = o.minute_points(v[3], DAY)
        self.assertEqual(len(points), 229)
        self.assertEqual(sum(p['volume'] for p in points), sum(r['volume_lots'] for r in v[3]))
        self.assertEqual(sum(p['amount'] for p in points), sum(r['amount'] for r in v[3]))

    def test_normal_data_unchanged(self):
        rows = fixture()[3]
        normalized, changes = o.normalize_lunch_bars(rows)
        self.assertEqual(rows, normalized)
        self.assertEqual(changes, [])

    def test_true_missing_1130_is_not_filled(self):
        v = list(fixture())
        v[3] = [r for r in v[3] if 'T11:30:' not in r['time']]
        with self.assertRaises(ValueError):
            o.minute_points(v[3], DAY)

    def test_other_missing_minute_still_rejected(self):
        rows = wire(fixture()[3])
        rows = [r for r in rows if 'T10:17:' not in r['time']]
        with self.assertRaises(ValueError):
            o.minute_points(rows, DAY)

    def test_missing_1449_still_rejected(self):
        with self.assertRaises(ValueError):
            o.minute_points(wire(fixture()[3])[:-1], DAY)

    def test_duplicate_1300_rejected(self):
        rows = wire(fixture()[3])
        rows.append(next(r for r in rows if 'T13:00:' in r['time']))
        with self.assertRaises(ValueError):
            o.minute_points(rows, DAY)

    def test_missing_neighbor_rejected(self):
        rows = [r for r in wire(fixture()[3]) if 'T13:01:' not in r['time']]
        with self.assertRaises(ValueError):
            o.normalize_lunch_bars(rows)

    def test_already_has_1130_no_remap(self):
        rows = fixture()[3]
        extra = {**rows[0], 'time': DAY + 'T13:00:00+08:00'}
        normalized, changes = o.normalize_lunch_bars(rows + [extra])
        self.assertEqual(changes, [])
        self.assertEqual(normalized[-1], extra)

    def test_multiple_days_keep_date_and_prices(self):
        a = wire(fixture()[3])
        b = [{**r, 'time': r['time'].replace(DAY, '2026-11-02')} for r in a]
        rows, changes = o.normalize_lunch_bars(b + a)
        self.assertEqual(len(changes), 2)
        self.assertEqual([r['close'] for r in rows], [r['close'] for r in b + a])

    def test_nonzero_seconds_rejected(self):
        rows = wire(fixture()[3])
        rows = [{**r, 'time': r['time'].replace('T13:00:00', 'T13:00:01')} for r in rows]
        with self.assertRaises(ValueError):
            o.normalize_lunch_bars(rows)

    def test_doctor_accepts_normalized_lunch_and_records_it(self):
        class Market(FakeMarket):
            def call(self, op, deadline, **kw):
                data = super().call(op, deadline, **kw)
                if op == 'bars' and kw['period'] == '1m':
                    data['bars'] = wire(data['bars'])
                return data
        with tempfile.TemporaryDirectory() as d, patch.object(o, 'Market', Market), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(o.doctor(Path(d)), 0)
            report = json.loads(next(Path(d).glob('observer_data/doctor/*/doctor.json')).read_text())
            self.assertEqual(report['minute_validation'][0]['required'], 229)
            self.assertEqual(len(report['minute_validation'][0]['time_adjustments']), 1)

    def test_doctor_rejects_other_missing_minute(self):
        class Market(FakeMarket):
            def call(self, op, deadline, **kw):
                data = super().call(op, deadline, **kw)
                if op == 'bars' and kw['period'] == '1m':
                    data['bars'] = [r for r in wire(data['bars']) if 'T10:17:' not in r['time']]
                return data
        with tempfile.TemporaryDirectory() as d, patch.object(o, 'Market', Market), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(o.doctor(Path(d)), 2)

if __name__ == '__main__':
    unittest.main()
